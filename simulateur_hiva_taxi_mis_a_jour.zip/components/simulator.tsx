
'use client';

import { useState } from 'react';

const t = {
  fr: {
    title: "Simulateur de tarif",
    distance: "Distance (en km)",
    time: "Heure de la course (0-23)",
    bags: "Nombre de bagages (>5kg)",
    height: "Lieu en hauteur ?",
    large: "Nombre d'objets encombrants (glacière, surfboard…)",
    people: "Nombre total de passagers",
    calculate: "Calculer",
    result: "Tarif estimé : ",
    lang: "Langue"
  },
  en: {
    title: "Fare Simulator",
    distance: "Distance (in km)",
    time: "Time of the ride (0-23)",
    bags: "Number of bags (>5kg)",
    height: "High place?",
    large: "Number of bulky items (cooler, surfboard…)",
    people: "Total number of passengers",
    calculate: "Calculate",
    result: "Estimated fare: ",
    lang: "Language"
  }
};

export default function Simulator() {
  const [distance, setDistance] = useState(0);
  const [hour, setHour] = useState(12);
  const [bags, setBags] = useState(0);
  const [isHigh, setIsHigh] = useState(false);
  const [largeItems, setLargeItems] = useState(0);
  const [people, setPeople] = useState(1);
  const [fare, setFare] = useState<number|null>(null);
  const [language, setLanguage] = useState<'fr'|'en'>('fr');

  const calculateFare = () => {
    const base = 1000;
    const perKm = hour >= 20 || hour < 6 ? 260 : 160;
    let result = base + (distance * perKm);
    result += bags * 100;
    if (isHigh) result += 500;
    result += largeItems * 500;
    if (people > 4) result += 500;
    setFare(result);
  };

  return (
    <div className="p-4 max-w-xl mx-auto bg-green-100 rounded-2xl shadow-md space-y-4">
      <h2 className="text-xl font-semibold">{t[language].title}</h2>

      <div className="grid gap-2">
        <label>{t[language].distance}</label>
        <input type="number" value={distance} onChange={e => setDistance(Number(e.target.value))} className="w-full p-2 border rounded" />

        <label>{t[language].time}</label>
        <input type="number" value={hour} onChange={e => setHour(Number(e.target.value))} className="w-full p-2 border rounded" />

        <label>{t[language].bags}</label>
        <input type="number" value={bags} onChange={e => setBags(Number(e.target.value))} className="w-full p-2 border rounded" />

        <label>{t[language].height}</label>
        <input type="checkbox" checked={isHigh} onChange={e => setIsHigh(e.target.checked)} />

        <label>{t[language].large}</label>
        <input type="number" value={largeItems} onChange={e => setLargeItems(Number(e.target.value))} className="w-full p-2 border rounded" />

        <label>{t[language].people}</label>
        <input type="number" value={people} onChange={e => setPeople(Number(e.target.value))} className="w-full p-2 border rounded" />

        <button onClick={calculateFare} className="bg-blue-600 text-white px-4 py-2 rounded">{t[language].calculate}</button>
      </div>

      {fare !== null && (
        <div className="text-lg font-bold">
          {t[language].result} {fare} XPF
        </div>
      )}

      <div className="mt-4">
        <label>{t[language].lang}</label>
        <select value={language} onChange={e => setLanguage(e.target.value as 'fr'|'en')} className="ml-2 border p-1 rounded">
          <option value="fr">Français</option>
          <option value="en">English</option>
        </select>
      </div>
    </div>
  );
}

"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { CalendarIcon, Clock, MapPin, Navigation } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"
import { format } from "date-fns"
import MapComponent from "./map-component"

export default function BookingForm() {
  const router = useRouter()
  const [date, setDate] = useState<Date>()
  const [pickupLocation, setPickupLocation] = useState("")
  const [destination, setDestination] = useState("")
  const [vehicleType, setVehicleType] = useState("")
  const [estimatedFare, setEstimatedFare] = useState<number | null>(null)
  const [showMap, setShowMap] = useState(false)

  const calculateFare = () => {
    // Simple fare calculation for demo purposes
    // In a real app, this would use distance, time, and vehicle type
    if (pickupLocation && destination && vehicleType) {
      const baseFare = vehicleType === "standard" ? 10 : vehicleType === "premium" ? 15 : 20
      const randomDistance = Math.floor(Math.random() * 10) + 1 // 1-10 km
      const farePerKm = vehicleType === "standard" ? 2 : vehicleType === "premium" ? 3 : 4
      const calculatedFare = baseFare + randomDistance * farePerKm
      setEstimatedFare(calculatedFare)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // In a real app, this would send the booking data to an API
    const bookingData = {
      pickupLocation,
      destination,
      date: date ? format(date, "PPP") : "",
      vehicleType,
      estimatedFare,
    }

    console.log("Booking submitted:", bookingData)

    // Navigate to confirmation page
    router.push(
      `/booking-confirmation?pickup=${encodeURIComponent(pickupLocation)}&destination=${encodeURIComponent(destination)}&fare=${estimatedFare}`,
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid gap-2">
        <Label htmlFor="pickup">Pickup Location</Label>
        <div className="relative">
          <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="pickup"
            placeholder="Enter pickup address"
            className="pl-8"
            value={pickupLocation}
            onChange={(e) => setPickupLocation(e.target.value)}
            required
          />
        </div>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="destination">Destination</Label>
        <div className="relative">
          <Navigation className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            id="destination"
            placeholder="Enter destination address"
            className="pl-8"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            required
          />
        </div>
      </div>

      <Button type="button" variant="outline" className="w-full" onClick={() => setShowMap(!showMap)}>
        {showMap ? "Hide Map" : "Show Map"}
      </Button>

      {showMap && (
        <Card className="border">
          <CardContent className="p-0">
            <MapComponent pickupLocation={pickupLocation} destination={destination} />
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label htmlFor="date">Date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                id="date"
                variant={"outline"}
                className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
            </PopoverContent>
          </Popover>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="time">Time</Label>
          <div className="relative">
            <Clock className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Select required>
              <SelectTrigger id="time" className="pl-8">
                <SelectValue placeholder="Select time" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="now">As soon as possible</SelectItem>
                <SelectItem value="morning">Morning (8-12)</SelectItem>
                <SelectItem value="afternoon">Afternoon (12-5)</SelectItem>
                <SelectItem value="evening">Evening (5-9)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="vehicle">Vehicle Type</Label>
        <Select value={vehicleType} onValueChange={setVehicleType} required>
          <SelectTrigger id="vehicle">
            <SelectValue placeholder="Select vehicle type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="standard">Standard (Sedan)</SelectItem>
            <SelectItem value="premium">Premium (SUV)</SelectItem>
            <SelectItem value="luxury">Luxury (Executive)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button
        type="button"
        variant="outline"
        className="w-full"
        onClick={calculateFare}
        disabled={!pickupLocation || !destination || !vehicleType}
      >
        Calculate Fare
      </Button>

      {estimatedFare !== null && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Estimated Fare</CardTitle>
            <CardDescription>Based on distance and vehicle type</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">${estimatedFare.toFixed(2)}</p>
          </CardContent>
        </Card>
      )}

      <Button
        type="submit"
        className="w-full"
        disabled={!pickupLocation || !destination || !date || !vehicleType || estimatedFare === null}
      >
        Book Now
      </Button>
    </form>
  )
}

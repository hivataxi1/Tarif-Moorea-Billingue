"use client"

import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { CheckCircle, ArrowRight, Calendar, MapPin, Navigation, Car } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function BookingConfirmation() {
  const searchParams = useSearchParams()

  const pickup = searchParams.get("pickup") || "Unknown location"
  const destination = searchParams.get("destination") || "Unknown destination"
  const fare = searchParams.get("fare") || "0"

  // Generate a random booking ID
  const bookingId = `HT${Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0")}`

  // Generate a random driver name
  const drivers = ["John Smith", "Maria Garcia", "Tama Nui", "Hina Moana", "Maui Tama"]
  const driver = drivers[Math.floor(Math.random() * drivers.length)]

  // Generate a random car model
  const cars = ["Toyota Prius", "Honda Civic", "Tesla Model 3", "Ford Escape", "Hyundai Sonata"]
  const car = cars[Math.floor(Math.random() * cars.length)]

  // Generate a random license plate
  const licensePlate = `HV-${Math.floor(Math.random() * 999)}-${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`

  // Generate a random arrival time (5-15 minutes from now)
  const arrivalMinutes = Math.floor(Math.random() * 10) + 5

  return (
    <div className="container max-w-4xl py-12">
      <div className="flex flex-col items-center text-center mb-8">
        <div className="rounded-full bg-primary/10 p-4 mb-4">
          <CheckCircle className="h-12 w-12 text-primary" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight">Booking Confirmed!</h1>
        <p className="text-muted-foreground mt-2">Your taxi is on the way. Here are your booking details.</p>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Booking Details</CardTitle>
          <CardDescription>Booking ID: {bookingId}</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="grid gap-3">
            <div className="flex items-start gap-4">
              <MapPin className="mt-0.5 h-5 w-5 text-primary" />
              <div>
                <div className="font-semibold">Pickup Location</div>
                <div className="text-sm text-muted-foreground">{pickup}</div>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Navigation className="mt-0.5 h-5 w-5 text-primary" />
              <div>
                <div className="font-semibold">Destination</div>
                <div className="text-sm text-muted-foreground">{destination}</div>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Calendar className="mt-0.5 h-5 w-5 text-primary" />
              <div>
                <div className="font-semibold">Date & Time</div>
                <div className="text-sm text-muted-foreground">
                  {new Date().toLocaleDateString()} • As soon as possible
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-lg border p-4">
            <div className="grid gap-3">
              <div className="flex items-center justify-between">
                <div className="font-semibold">Fare</div>
                <div>${fare}</div>
              </div>
              <div className="flex items-center justify-between">
                <div className="font-semibold">Payment Method</div>
                <div>Cash on delivery</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Driver Information</CardTitle>
          <CardDescription>Your driver will arrive in approximately {arrivalMinutes} minutes</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6">
          <div className="flex items-center gap-4">
            <div className="rounded-full bg-muted h-16 w-16 flex items-center justify-center">
              <span className="text-2xl font-semibold">
                {driver
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </span>
            </div>
            <div>
              <div className="font-semibold">{driver}</div>
              <div className="text-sm text-muted-foreground">⭐ 4.9 (120 trips)</div>
            </div>
          </div>

          <div className="grid gap-3">
            <div className="flex items-start gap-4">
              <Car className="mt-0.5 h-5 w-5 text-primary" />
              <div>
                <div className="font-semibold">Vehicle</div>
                <div className="text-sm text-muted-foreground">
                  {car} • {licensePlate}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full">
            Contact Driver
          </Button>
        </CardFooter>
      </Card>

      <div className="flex flex-col items-center gap-4">
        <Button asChild>
          <Link href="/bookings">
            View All Bookings
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
        <Button variant="outline" asChild>
          <Link href="/">Back to Home</Link>
        </Button>
      </div>
    </div>
  )
}

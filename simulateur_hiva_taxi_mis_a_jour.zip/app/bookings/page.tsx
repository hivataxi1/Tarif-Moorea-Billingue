import Link from "next/link"
import { ArrowRight, Calendar, Clock, MapPin, Navigation } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function BookingsPage() {
  // Mock data for bookings
  const bookings = [
    {
      id: "HT1234",
      date: "May 12, 2025",
      time: "10:30 AM",
      pickup: "Hiva Airport",
      destination: "Pearl Resort, Hiva",
      status: "completed",
      fare: 35.5,
    },
    {
      id: "HT5678",
      date: "May 14, 2025",
      time: "2:15 PM",
      pickup: "Pearl Resort, Hiva",
      destination: "Hiva Market",
      status: "upcoming",
      fare: 22.75,
    },
    {
      id: "HT9012",
      date: "May 14, 2025",
      time: "7:00 PM",
      pickup: "Hiva Market",
      destination: "Pearl Resort, Hiva",
      status: "upcoming",
      fare: 24.0,
    },
  ]

  return (
    <div className="container py-10">
      <div className="flex flex-col gap-2 mb-8">
        <h1 className="text-3xl font-bold tracking-tight">My Bookings</h1>
        <p className="text-muted-foreground">View and manage your taxi bookings</p>
      </div>

      <div className="grid gap-6">
        {bookings.map((booking) => (
          <Card key={booking.id}>
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle>Booking #{booking.id}</CardTitle>
                <CardDescription className="flex items-center gap-1 mt-1">
                  <Calendar className="h-3.5 w-3.5" />
                  {booking.date} • {booking.time}
                </CardDescription>
              </div>
              <Badge variant={booking.status === "completed" ? "secondary" : "default"}>
                {booking.status === "completed" ? "Completed" : "Upcoming"}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                <div className="flex items-start gap-3">
                  <MapPin className="mt-0.5 h-5 w-5 text-primary" />
                  <div>
                    <div className="font-medium">Pickup</div>
                    <div className="text-sm text-muted-foreground">{booking.pickup}</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Navigation className="mt-0.5 h-5 w-5 text-primary" />
                  <div>
                    <div className="font-medium">Destination</div>
                    <div className="text-sm text-muted-foreground">{booking.destination}</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="mt-0.5 h-5 w-5 text-primary" />
                  <div>
                    <div className="font-medium">Fare</div>
                    <div className="text-sm text-muted-foreground">${booking.fare.toFixed(2)}</div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              {booking.status === "upcoming" ? (
                <>
                  <Button variant="outline" size="sm">
                    Cancel Booking
                  </Button>
                  <Button size="sm">
                    View Details
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </>
              ) : (
                <>
                  <Button variant="outline" size="sm">
                    Book Again
                  </Button>
                  <Button size="sm">
                    View Receipt
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-8 text-center">
        <Button asChild>
          <Link href="/">Book a New Taxi</Link>
        </Button>
      </div>
    </div>
  )
}
